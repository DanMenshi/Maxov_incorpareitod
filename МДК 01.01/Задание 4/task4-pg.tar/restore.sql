--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE task_db;
--
-- Name: task_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE task_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Russian_Russia.1251';


ALTER DATABASE task_db OWNER TO postgres;

\unrestrict (null)
\connect task_db
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE task_db; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE task_db IS 'Для заданий ААМ';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.accounts (
    account_number character varying(20) NOT NULL,
    client_id integer,
    balance integer DEFAULT 0,
    has_welcome_bonus boolean DEFAULT false
);


ALTER TABLE public.accounts OWNER TO postgres;

--
-- Name: clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clients (
    id integer NOT NULL,
    first_name character varying(50) NOT NULL,
    second_name character varying(50) NOT NULL,
    client_level character varying(20) NOT NULL
);


ALTER TABLE public.clients OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.clients_id_seq OWNER TO postgres;

--
-- Name: clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clients_id_seq OWNED BY public.clients.id;


--
-- Name: fit_clients; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fit_clients (
    id integer NOT NULL,
    full_name character varying(100) NOT NULL,
    gender character varying(10) NOT NULL,
    age integer NOT NULL
);


ALTER TABLE public.fit_clients OWNER TO postgres;

--
-- Name: fit_clients_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fit_clients_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fit_clients_id_seq OWNER TO postgres;

--
-- Name: fit_clients_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fit_clients_id_seq OWNED BY public.fit_clients.id;


--
-- Name: fit_subscriptions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fit_subscriptions (
    id integer NOT NULL,
    client_id integer,
    sub_type character varying(20) NOT NULL,
    reg_date date DEFAULT CURRENT_DATE,
    end_date date NOT NULL
);


ALTER TABLE public.fit_subscriptions OWNER TO postgres;

--
-- Name: fit_subscriptions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fit_subscriptions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fit_subscriptions_id_seq OWNER TO postgres;

--
-- Name: fit_subscriptions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fit_subscriptions_id_seq OWNED BY public.fit_subscriptions.id;


--
-- Name: fit_visits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fit_visits (
    id integer NOT NULL,
    client_id integer,
    zone character varying(20) NOT NULL,
    entry_time time without time zone DEFAULT CURRENT_TIME
);


ALTER TABLE public.fit_visits OWNER TO postgres;

--
-- Name: fit_visits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.fit_visits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.fit_visits_id_seq OWNER TO postgres;

--
-- Name: fit_visits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.fit_visits_id_seq OWNED BY public.fit_visits.id;


--
-- Name: clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients ALTER COLUMN id SET DEFAULT nextval('public.clients_id_seq'::regclass);


--
-- Name: fit_clients id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_clients ALTER COLUMN id SET DEFAULT nextval('public.fit_clients_id_seq'::regclass);


--
-- Name: fit_subscriptions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_subscriptions ALTER COLUMN id SET DEFAULT nextval('public.fit_subscriptions_id_seq'::regclass);


--
-- Name: fit_visits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_visits ALTER COLUMN id SET DEFAULT nextval('public.fit_visits_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.accounts (account_number, client_id, balance, has_welcome_bonus) FROM stdin;
\.
COPY public.accounts (account_number, client_id, balance, has_welcome_bonus) FROM '$$PATH$$/5045.dat';

--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clients (id, first_name, second_name, client_level) FROM stdin;
\.
COPY public.clients (id, first_name, second_name, client_level) FROM '$$PATH$$/5044.dat';

--
-- Data for Name: fit_clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fit_clients (id, full_name, gender, age) FROM stdin;
\.
COPY public.fit_clients (id, full_name, gender, age) FROM '$$PATH$$/5047.dat';

--
-- Data for Name: fit_subscriptions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fit_subscriptions (id, client_id, sub_type, reg_date, end_date) FROM stdin;
\.
COPY public.fit_subscriptions (id, client_id, sub_type, reg_date, end_date) FROM '$$PATH$$/5049.dat';

--
-- Data for Name: fit_visits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fit_visits (id, client_id, zone, entry_time) FROM stdin;
\.
COPY public.fit_visits (id, client_id, zone, entry_time) FROM '$$PATH$$/5051.dat';

--
-- Name: clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clients_id_seq', 17, true);


--
-- Name: fit_clients_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fit_clients_id_seq', 6, true);


--
-- Name: fit_subscriptions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fit_subscriptions_id_seq', 6, true);


--
-- Name: fit_visits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.fit_visits_id_seq', 1, false);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (account_number);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: fit_clients fit_clients_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_clients
    ADD CONSTRAINT fit_clients_pkey PRIMARY KEY (id);


--
-- Name: fit_subscriptions fit_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_subscriptions
    ADD CONSTRAINT fit_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: fit_visits fit_visits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_visits
    ADD CONSTRAINT fit_visits_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: fit_subscriptions fit_subscriptions_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_subscriptions
    ADD CONSTRAINT fit_subscriptions_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.fit_clients(id) ON DELETE CASCADE;


--
-- Name: fit_visits fit_visits_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fit_visits
    ADD CONSTRAINT fit_visits_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.fit_clients(id);


--
-- PostgreSQL database dump complete
--

